Xunit: output test results in xunit format
==========================================

.. autoplugin :: nose.plugins.xunit