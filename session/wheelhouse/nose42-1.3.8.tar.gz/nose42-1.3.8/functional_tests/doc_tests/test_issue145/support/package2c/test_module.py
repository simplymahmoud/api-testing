from package1.test_module import TestClass, TestCase
