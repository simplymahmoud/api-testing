# -*- coding: utf-8 -*-
import unittest
class Test(unittest.TestCase):
    def test(self):
        print u"Unicöde"
        assert 1 == 2
